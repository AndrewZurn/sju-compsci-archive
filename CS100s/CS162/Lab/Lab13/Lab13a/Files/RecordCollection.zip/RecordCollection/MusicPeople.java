package RecordCollection;

public class MusicPeople {
  
  
  
  
  
}