package RecordCollection;

import java.util.*;
import java.io.*;

public class Record {
  
  private String title, genre, producer, releaseDate, format, commentary;
  private ArrayList<String> artistName;
  private ArrayList<Track> tracks;
  private int numberOfTracks;
  
  
  
  
  public Record (String title, ArrayList<String> artistName, String genre, String producer, String releaseDate, 
                 int numberOfTracks, ArrayList<Track> tracks, String format, String commentary) {
    
    this.title = title;
    this.artistName = artistName;
    this.genre = genre;
    this.producer = producer;
    this.releaseDate = releaseDate;
    this.numberOfTracks = numberOfTracks;
    this.tracks = tracks;
    this.format = format;
    this.commentary = commentary;
    
    
  }
  
  private String getTitle () {
    return title;
  }
  
  
}