package RecordCollection;

public class Artist {
  
  
  
  
  
  
  
}