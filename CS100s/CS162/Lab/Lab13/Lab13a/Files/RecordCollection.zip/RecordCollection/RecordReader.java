package RecordCollection;

import fileStuff.*;
import java.util.*;
import java.io.*;

public class RecordReader implements Serializable {
  
  private String title, artistGenre, recordGenre, commentary, format, releaseDate, producer, songTitle, songReleaseDate;
  private ArrayList<MusicPeople> people;
  private ArrayList<Integer> trackNumbers;
  private int numberOfTracks, songRating, songNumber, songLength;
  private TreeMap<String, Track> tracks;
  private ArrayList<Track> recordTracks;
  private ArrayList<String> artistName;
  private Artist artist;
  private TreeMap<String, Record> recordMap;
  
  
  public RecordReader () throws Exception {
    
    ObjectOutputStream trackOutput = FileChooser.openObjectWriter();
    ObjectOutputStream artistOutput = FileChooser.openObjectWriter();
    ObjectOutputStream recordOutput = FileChooser.openObjectWriter();
    Scanner file = FileChooser.openScanner();
    
    while (file.hasNext()) {
      
      
      
      while (file.next() != "&") {
        
        recordTracks = new ArrayList<Track>();
        people = new ArrayList<MusicPeople>();
        artistName = new ArrayList<String>();
        trackNumbers = new ArrayList<Integer>();
        
        title = file.next(); 
        
        while (file.next() != "@") {
          
          artistName.add(file.next());
          
          artistGenre = file.next();
          
          while (file.next() != "#") {
            
            trackNumbers.add(file.nextInt());
          }
          file.next();
        }
        file.next();
        
        artist = new Artist(artistName, artistGenre, trackNumbers);
        
        recordGenre = file.next();
        
        producer = file.next();
        
        releaseDate = file.next();
        
        numberOfTracks = file.nextInt();
        
        if (file.next() != "#") {
          
          songTitle = file.next();
          songLength = file.nextInt();
          songNumber = file.nextInt();
          songRating = file.nextInt();
          songReleaseDate = file.next();
          
          while (file.next() != "#") {
            
            if (file.next() != "%") {
              
              people.add(new MusicPeople(file.next(), file.next()));
              
            }
            
            else {
              file.next();
            }
            
          }
          
        }
        
        recordTracks.add(new Track(songTitle, songLength, songNumber, songRating, songReleaseDate, people));
        
        tracks.put(songTitle, new Track(songTitle, songLength, songNumber, songRating, songReleaseDate, people));
        
        file.next();
          
        
//        for (int i = 1; i >= numberOfTracks; i++) {
//          
//          tracks.add(new Track(file.next(), file.nextInt(), file.nextInt(), file.nextInt(), file.next()));
//          
//          while (file.next() != "#") {
//            
//            if (file.next() != "%") {
//              
//              people.add(new MusicPeople(file.next(), file.next()));
//              
//            }
//            
//            else {
//              
//              file.next();
//              
//            }
//            
//          }
//          
//          file.next();
//          
//        }
//        
//        file.next();
        
        format = file.next();
        
        if (file.next() != "&") {
          commentary = file.next();
        }
        
      }
      
      recordMap.put(title, new Record(title, artistName, recordGenre, producer, releaseDate, numberOfTracks, recordTracks, format, commentary));
      
      file.next();
      
//      recordOutput.print(title + "/n");
//      for (String s: artistName) {
//        recordOutput.print(s + "/n");
//      }
//      recordOutput.print(recordGenre + "/n");
//      recordOutput.print(releaseDate + "/n");
//      recordOutput.print(numberOfTracks + "/n");
//      recordOutput.print(producer + "/n");
//      if (commentary != null) {
//        recordOutput.print(commentary + "/n");
//      }
      
    }
    
    
    
    
    
  }
  
//  private String setCommentary(String s){
//    commentary = s;
//    return commentary;
//  }
  
  
  
}