package RecordCollection;
import java.util.*;
import java.io.*;

public class Track implements Serializable{
  private String title, releaseDate, trackNum, rating, length;
  private String artist, composer;
  private ArrayList<MusicPeople> musicPeople;
  
  public Track(String title, String length, String trackNum, String rating, String releaseDate, ArrayList<MusicPeople> musicPeople){
    this.title = title;
    this.trackNum = trackNum;
    this.length=length;
    this.rating = rating;
    this.releaseDate = releaseDate;
    this.musicPeople = musicPeople;
//    artist = musicPeople.getArtist();
//    composer = musicPeople.getComposer();
  }
  
  public String getTitle(){
    return title;
  }
  public String getTrackNum(){
    return trackNum;
  }
  public String getRating(){
    return rating;
  }
  public String getLength(){
    return length;
  }
  public String getReleaseDate(){
    return releaseDate;
  }
//  public String getArtist(){
//    return musicPeople.getArtist();
//  }
  public void changeTitle(String newTitle){
    title = newTitle;
  }
  public void changeRating(String newRating){
    rating = newRating;
  }
  public void changeReleaseDate(String newReleaseDate){
    releaseDate = newReleaseDate;
  }
  public void changeTrackNum(String newTrackNum){
    trackNum = newTrackNum;
  }
  public void changeLength(String newLength){
    length = newLength;
  }
//  public void changeArtist(String newArtist){
//    artist = newArtist;
//  }
//  public void changeComposer(String newComposer){
//    composer = newComposer;
//  }
  
  public String toString(){
    return ("The title of the Track is: " + title + ". The Track Number is: " + trackNum + ". The Length is: " 
              + length + ". The Release Date of the Track was: " + releaseDate + ".");
  }
}