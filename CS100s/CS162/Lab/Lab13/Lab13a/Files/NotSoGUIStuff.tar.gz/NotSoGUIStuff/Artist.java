package RecordCollection;
import fileStuff.*;
import java.util.*;
import java.io.*;

public class Artist implements Serializable{
  private String artistName;
  private String artistGenre;
  private ArrayList<Integer> trackNumber;
  
  public Artist(String artistName, String artistGenre, ArrayList<Integer> trackNumber){
    this.artistName = artistName;
    this.artistGenre = artistGenre;
    this.trackNumber = trackNumber;
  }
  
  public String getArtist(){
    return artistName;
  }
  public String getGenre(){
    return artistGenre;
  }
  public Integer getNumOfTracks(){
    int count = 0;
    for(int i:trackNumber){
      count++;
    }
    return count;
  }
  public void changeArtist(String newArtist){
    artistName = newArtist;
  }
  public void changeGenre(String newGenre){
    artistGenre = newGenre;
  }
  
  public String toString (){
    
    return("The artist is " + getArtist() + " who plays " + getGenre() + " type of music");
    
  }
}

//public void changeTrackNum(???){





