/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package csci230radomskizurnhardy;

/**
 *
 * @author awzurn
 */
public class Debugger {
    
    public static void main(String args[]){
        System.out.println(AdminController.getSpecificUser(1).getUserName());
    }
}
