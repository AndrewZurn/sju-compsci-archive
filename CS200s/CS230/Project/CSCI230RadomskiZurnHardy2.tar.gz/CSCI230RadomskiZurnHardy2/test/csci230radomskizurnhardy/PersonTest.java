package csci230radomskizurnhardy;

import junit.framework.TestCase;

/**
 *
 * @author pghardy
 */
public class PersonTest extends TestCase{
    
    public PersonTest() {
    }
    /*
     * This is a blank test simply because all functionalities of this class are 
     * testedb within AdminTest and PersonTest.
     */
    public void testClass() {
        System.out.println("testClass");
        //All functionalities of this class are tested
        //within AdminTest and UserTest. No further
        //testing is necessary. 
    
    }
}
