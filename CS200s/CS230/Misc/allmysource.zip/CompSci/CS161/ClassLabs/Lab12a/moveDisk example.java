public void moveDisk(int start, int target){
  start.move(target.getX());
}