public class RunTestGUI{
  public static void main(String [] args){
    new TestGUI();
  }
}



