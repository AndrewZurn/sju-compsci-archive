import objectdraw.*;
import java.awt.*;
public interface Racer{
  public void move(double x, double y);
  
  public void setColor(Color x);
  
  public void start(); 
}