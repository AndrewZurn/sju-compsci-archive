import objectdraw.*;
import java.awt.*;



/**
 *Include your name and a description of the program here.
 */
public class LaundrySorter extends FrameWindowController
{
  // place constant and variable declarations here
  
  
  /**
   * Initialize the display with a colored rectangle for the first article 
   * of clothing along with 3 tubs labeled "White", "Dark", and "Colored". 
   */
   public void begin(){

   }

   
   /**
    * If the tub selected matches the color of the new laundry item, 
    * display success message and generate a new random color for hamper
    * otherwise display error message 
    */
  public void onMouseClick(Location point){
 
  }

}



