public class RunCalculator {
  public static void main(String [] args) {
    new Calculator();
  }
}