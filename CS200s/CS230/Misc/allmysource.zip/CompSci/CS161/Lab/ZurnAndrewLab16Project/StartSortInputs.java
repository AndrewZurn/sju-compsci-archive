public class StartSortInputs {
  public static void main(String [] args) {
    SortInputs s=new SortInputs();
    s.run();
  }
}
