public class StartSumInputs {
  public static void main(String [] args) {
    SumInputs s=new SumInputs();
    s.run();
  }
}
