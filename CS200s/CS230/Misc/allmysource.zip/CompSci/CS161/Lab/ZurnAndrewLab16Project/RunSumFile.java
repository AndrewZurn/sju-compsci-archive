public class RunSumFile {
  public static void main(String [] args) {
    SumFile sumfile=new SumFile(args[0]);
    sumfile.run();
  }
}