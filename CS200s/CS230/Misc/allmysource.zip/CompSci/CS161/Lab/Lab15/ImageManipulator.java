
public class ImageManipulator {
  public static void main(String []args ){
    ImageEdit manipulator = new ImageEdit(args[0]);
    }
  }