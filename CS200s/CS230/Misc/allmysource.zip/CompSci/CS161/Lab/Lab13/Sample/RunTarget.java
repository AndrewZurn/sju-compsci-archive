

public class RunTarget {
                      public static void main(String [] args) {
                               new TargetController();
                      }
             }
