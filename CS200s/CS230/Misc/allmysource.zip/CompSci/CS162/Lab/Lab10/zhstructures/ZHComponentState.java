package zhstructures;

/**
 * ZHComponentState is used to store the state of a BinaryTree.
 * (empty or not empty).
 */
public enum ZHComponentState {EMPTY,NOT_EMPTY};