public class OpenRecordGUI{
  public OpenRecordGUI() throws Exception{
    new RecordGUI();
  }

  public static void main(String [] args) throws Exception{
    new OpenRecordGUI();
  }
}